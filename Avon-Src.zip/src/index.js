const Avon = require("./structures/avonClient.js");
const client = new Avon();
module.exports = client;

require('http').createServer((req, res) => res.end(`24/7 Music`)).listen(3000)